Nuns on the Run line of sight utility by Roy Lazarovich.

An interactive line of sight utility that allows you to click on a spot to see all visible spots, or click and drag to see visible spots in a certain direction only.

All visible spots are highlighted on the map as well as printed at the side of the map in a sorted order which allows players to quickly find if their current position is on the list.

All visibility information is human-editable through a simple text config file so you can make corrections if you need any.